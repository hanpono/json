import datapane as dp
import pandas as pd
import streamlit as st
from plotly.graph_objects import Figure


class Writer:
    def __init__(self):
        self._items = []
        self.components = []
        self.deferred = []
        self._placeholder = None

    def set_page_config(self, title: str, layout="wide"):
        self.deferred.append((st.set_page_config(title, layout=layout)))
        self.components.append(dp.Text(f'Project: {title}'))

    def title(self, md: str):
        self.markdown(f"<h1 id='{md.replace(' ', '-').lower()}'>{md}</h1>", unsafe_allow_html=True)
        self._items.append(f"* <a href='#{md.replace(' ', '-').lower()}'>{md}</a>")

    def header(self, md: str):
        self.markdown(f"<h2 id='{md.replace(' ', '-').lower()}'>{md}</h2>", unsafe_allow_html=True)
        self._items.append(f"  * <a href='#{md.replace(' ', '-').lower()}'>{md}</a>")

    def subheader(self, md: str, anchor=None):
        self.markdown(f"<h3 id='{md.replace(' ', '-').lower()}'>{md}</h3>", unsafe_allow_html=True)
        self._items.append(f"    * <a href='#{md.replace(' ', '-').lower()}'>{md}</a>")

    def write(self, md):
        self.deferred.append(st.write(md))
        self.components.append(dp.DataTable(md) if type(md) is pd.DataFrame else dp.Text(md))

    def markdown(self, md: str, unsafe_allow_html=True):
        self.deferred.append((st.markdown(md, unsafe_allow_html=unsafe_allow_html)))
        self.components.append(dp.Text(md))

    def placeholder(self, sidebar=False):
        self._placeholder = st.sidebar.empty() if sidebar else st.empty()

    def plotly_chart(self, plotly_fig: Figure):
        self.deferred.append((st.plotly_chart(plotly_fig)))
        self.components.append(dp.Plot(plotly_fig))

    def columns(self, spec):
        self.deferred.append((st.columns(spec)))

    def dataframe(self, data):
        self.deferred.append((st.dataframe(data)))
        self.components.append(dp.Table(data))

    def generate(self):
        if self._placeholder:
            self._placeholder.markdown("\n".join(self._items), unsafe_allow_html=True)

    def download(self):
        index = 0
        for it in range(len(self.components)):
            try:
                if 'Table of contents' not in self.components[it].content:
                    index += 1
                else:
                    break
            except AttributeError:
                pass
        self.components.insert(index + 1, dp.Text("\n".join(self._items)))
        return dp.App(*self.components).stringify()
