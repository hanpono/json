import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from utils import Writer

global df
# Table of content
writer = Writer()
writer.set_page_config("Title of Project", layout='wide')  # global params of displaying page

# Title block
writer.title("Title of Project")

writer.markdown('Author: ')
writer.markdown('Date: ')
writer.markdown('Department: ')
writer.markdown('Machine/Place: ')

# Summary block
writer.subheader('Summary')

writer.markdown('Text about this project...' * 20)

writer.subheader("Table of contents", anchor="tableofcontents")
writer.placeholder()

writer.header("Topic 1")
writer.markdown('Text ' * 50)

writer.header("Topic 2")
writer.markdown('Text ' * 50)

writer.header("Topic 3")
writer.markdown('* Result 1: ')
writer.markdown('* Result 2: ')
writer.markdown('* Result 3: ')

writer.header("Topic 4")
writer.markdown('Text ' * 20)
writer.markdown("**Код**: загрузка данных из `csv` в Pandas `dataframe`")

# File uploader
uploaded_file = st.file_uploader("Choose file")
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    writer.write(df.head(10))

# Data visualizer
_, col2, _ = st.columns([1, 6, 1])
# 1
if uploaded_file is not None and df is not None:
    df_g = df.groupby(['Survived', 'Sex']).size().reset_index()
    df_g['percentage'] = df.groupby(['Survived', 'Sex']).size().groupby(level=1).apply(
        lambda item: 100 * item / float(item.sum())).values
    df_g.columns = ['Survived', 'Sex', 'Counts', 'Percentage']

    fig = go.Figure()

    x = df_g['Sex']
    y = df_g['Percentage']
    z = df_g['Survived']

    fig.add_trace(go.Bar(x=x, y=y,
                         text=y,
                         textposition='auto',
                         texttemplate="%{y:.1f}",
                         marker=dict(
                             color=z,
                             colorscale='Tealgrn'
                         ),
                         width=0.2
                         )
                  )

    fig.update_layout(xaxis_ticks='outside',  # Adding Tick Marks on X axis
                      yaxis_ticks='outside',  # Adding Tick Marks on Y axis
                      yaxis_ticksuffix='%',  # Adds $ as Prefix
                      paper_bgcolor='rgba(0,0,0,0)',  # Transparent Paper BG color
                      plot_bgcolor='rgba(0,0,0,0)',  # Transparent Plot BG color
                      title="Survival ratio by Male vs Female",
                      title_x=0.45,  # Center title
                      title_yanchor='bottom',  # Title Y Axis position
                      title_y=0.88,  # Title Y Axis position
                      title_font_size=18,  # Title Y Axis position
                      legend=dict(
                          x=0.8,
                          y=0.9,
                          traceorder="normal"
                      ),
                      autosize=False,
                      width=800,
                      height=450,
                      xaxis=dict(
                          linecolor="#BCCCDC"
                      ),
                      yaxis=dict(
                          linecolor="#BCCCDC"
                      )
                      )
    with col2:
        writer.markdown("**Код**: визуализация 1")
        writer.plotly_chart(fig)

# 2
if uploaded_file is not None and df is not None:
    df['Embarked'] = df['Embarked'].fillna('Unknown')
    embarked_points = df['Embarked'].sort_values(ascending=True).unique()
    embarked_points = embarked_points.tolist()

    total_embarked = df.groupby(['Embarked'], as_index=True, sort=True).count()['Survived'].to_list()

    embarked_pie = go.Pie(labels=embarked_points, values=total_embarked)
    embarked_pie_layout = go.Layout(title='Embarked', colorway=['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A',
                                                                '#19D3F3', '#FF6692', '#B6E880', '#FF97FF', '#FECB52'])
    embarked_pie_fig = go.Figure(data=[embarked_pie], layout=embarked_pie_layout)

    with col2:
        writer.markdown("**Код**: визуализация 2")
        writer.plotly_chart(embarked_pie_fig)

if uploaded_file is not None and df is not None:
    writer.markdown("Text " * 36)

# Topic 5
writer.header("Topic 5")
writer.markdown('Text ' * 20)
writer.markdown("**Код**: график `plotly`")

df_iris = px.data.iris()

fig = px.bar(df_iris, x="sepal_width", y="sepal_length", color="species",
             hover_data=['petal_width'], barmode='stack',
             color_discrete_sequence=['indianred'])

writer.plotly_chart(fig)

writer.markdown('Text ' * 50)

# Topic 6
writer.header("Topic 6")
writer.markdown('Text ' * 20)
writer.markdown("**Код**: гистограмма")

df_data_tips = px.data.tips()
fig = px.histogram(df_data_tips, x="total_bill",
                   title='Histogram of bills',
                   labels={'total_bill': 'total bill'},  # can specify one label per df column
                   opacity=0.8,
                   log_y=True,  # represent bars with log scale
                   color_discrete_sequence=['indianred']  # color of histogram bars
                   )

writer.plotly_chart(fig)

writer.header("Summary")
writer.markdown("""С возможностью корректирования, добавления, изменения модулей.

Сохранение документа, как `html` и печать в `pdf`.
""")

with st.sidebar:
    st.download_button(label="Download Report", file_name="report.html", mime="text/html", data=writer.download())

writer.generate()
