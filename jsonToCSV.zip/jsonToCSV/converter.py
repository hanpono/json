import json
import os
import pandas as pd


def find_json_files(dir_name: str) -> list:
    '''поиск всех json файлов в указаной директории dir_name'''

    files = [os.path.join(dir_name, file) for file in os.listdir(dir_name) if file.endswith(".json")]
    files = [filepath for filepath in files if os.path.isfile(filepath)]
    return files


def read_data_from_json(filename: str) -> json:
    '''функция считывает файл и возвращает json объэкт'''

    with open(filename) as file:
        js = json.load(file)
    return js


def parse_one_id_from_json(lst: list) -> dict:
    '''функция принимает список в котором первый елемент это временной штамп
    второй - айди, а третий елемент это словарь атрибутов для даного айди
    возвращает словарь где ключ это название колонки датафрейма, а значение это значение'''
    res = {}
    if len(lst) > 2:
        res["Timestamp"] = lst[0]
        res["ID"] = lst[1]
        for key, value in lst[2].items():
            if "value" in value:
                res[key] = value["value"]
            if "status" in value:
                res[f"{key}_Status"] = value["status"]

    return res


def jsons_to_pandas(dirname: str) -> pd.DataFrame:
    '''функция сканирует указанную директорию на наличие json файлов
    затем для каждого найденного файла открывает его и для каждого елемента
    из файла получает словарь который будет добавлен в датафрейм
    '''
    files = find_json_files(dirname)
    data = []
    for json_file in files:
        js = read_data_from_json(json_file)
        for row in js:
            data.append(parse_one_id_from_json(row))
    if data:
        df = pd.DataFrame.from_dict(data)
        df.set_index(df.columns[0], inplace=True)
        return df
    


if __name__ == "__main__":
    dirname = "files/" # директория с файлами
    df = jsons_to_pandas(dirname) # получаем пандас датафрейм
    if df is not None:
        df.to_csv("out.csv") # сохраняем csv
